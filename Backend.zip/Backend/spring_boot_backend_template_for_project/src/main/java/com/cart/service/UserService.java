package com.cart.service;

import java.util.List;

import com.cart.dto.UserDto;

public interface UserService {
	public UserDto getUserById(Long id);
	public List<UserDto> getAllUsers();
	public String addUser(UserDto userDto);
	public String updateUserDetails(UserDto userDto);
	public String deleteUserDetails(Long id); //Used wrapper class
}
