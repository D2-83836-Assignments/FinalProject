package com.cart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cart.pojo.CartItem;

public interface CartDao extends JpaRepository<CartItem, Long>{
}
