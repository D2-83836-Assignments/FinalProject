package com.cart.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class CartItemDto{
	private Long id;
	private String title;
	private String description;
	private String imgpath;
	private double price;
	private double discount;
	private int quantity;
	private double netprice;
	private boolean isRemoved;
}