package com.cart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cart.dto.UserDto;
import com.cart.service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {
	@Autowired
	private UserService userService;
	
	@GetMapping("/{userId}")
	public ResponseEntity<?> getUserDetails(@PathVariable Long userId)
	{
		try
		{
			System.out.println("In getUserDetails id="+userId);
			return ResponseEntity.ok(userService.getUserById(userId));
		}
		catch(RuntimeException ex)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
		}
	}
	
	@GetMapping
	public ResponseEntity<?> getAllUserDetails()
	{
		try
		{
			return ResponseEntity.status(HttpStatus.OK).body(userService.getAllUsers());
		}
		catch(RuntimeException ex)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
		}
	}
	
	@PostMapping
	public ResponseEntity<?> addUser(@RequestBody UserDto userDto)
	{
		try
		{
			return ResponseEntity.status(HttpStatus.CREATED).body(userService.addUser(userDto));
		}
		catch(RuntimeException ex)
		{
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
		}
	}
	
	@PutMapping("/update")
	public ResponseEntity<?> updateUserDetails(@RequestBody UserDto userdto)
	{
		try
		{
			return ResponseEntity.status(HttpStatus.CREATED).body(userService.updateUserDetails(userdto));
		}
		catch(RuntimeException ex)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
		}
	}
	
	@DeleteMapping("/delete/{userId}")
	public ResponseEntity<?> deleteUserDetails(@PathVariable Long userId)
	{
		try
		{
			return ResponseEntity.ok(userService.deleteUserDetails(userId));
		}
		catch(RuntimeException ex)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
		}
	}

}
