package com.cart.service;

import java.util.List;

import com.cart.dto.CartItemDto;
import com.cart.pojo.*;

public interface CartService {
	
	public List<CartItemDto> getAllCartItems();
	public String addItemToCart(CartItemDto item);
	public String updateItemInCart(CartItemDto item);
	public String deleteItemfromCart(Long id);

}
