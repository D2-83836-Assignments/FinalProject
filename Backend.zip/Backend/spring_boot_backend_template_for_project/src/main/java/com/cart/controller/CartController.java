package com.cart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cart.dto.CartItemDto;
import com.cart.service.CartService;

@RestController
@RequestMapping("/cart")
@CrossOrigin(origins = "http://localhost:3000")
public class CartController {
	@Autowired
	private CartService cartService;
	
	@GetMapping
	public ResponseEntity<?> getAllCartItems()
	{
		try
		{
			return ResponseEntity.status(HttpStatus.OK).body(cartService.getAllCartItems());
		}
		catch(RuntimeException ex)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getMessage());
		}
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> addItemToCart(@RequestBody CartItemDto newitem)
	{
		try
		{
			return ResponseEntity.ok(cartService.addItemToCart(newitem));
		}
		catch(RuntimeException ex)
		{
			return ResponseEntity.status(HttpStatus.CONFLICT).body(ex.getMessage());
		}
	}
	
	@PutMapping("/remove/{itemId}")
	public ResponseEntity<?> removeItemFromCart(@PathVariable Long itemId)
	{
		try
		{
			return ResponseEntity.status(HttpStatus.OK).body(cartService.deleteItemfromCart(itemId));
		}
		catch(RuntimeException ex)
		{
			return ResponseEntity.status(HttpStatus.NOT_MODIFIED).body(ex.getMessage());
		}
	}
	
}
