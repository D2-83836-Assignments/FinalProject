package com.cart.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cart.pojo.User;

public interface UserDao extends JpaRepository<User, Long>{

}
