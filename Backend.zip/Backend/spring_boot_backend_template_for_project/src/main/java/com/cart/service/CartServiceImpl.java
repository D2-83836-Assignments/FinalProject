package com.cart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cart.dao.CartDao;
import com.cart.dto.CartItemDto;
import com.cart.pojo.CartItem;

@Service
@Transactional
public class CartServiceImpl implements CartService {
	@Autowired
	private CartDao cartdao;
	
	@Autowired
	private ModelMapper mapper;

	@Override
	public List<CartItemDto> getAllCartItems() {
		List<CartItem> cartlist = cartdao.findAll();
		List<CartItemDto> result = new ArrayList<CartItemDto>();
		
		cartlist.forEach((item) -> {
			result.add(mapper.map(item, CartItemDto.class));
		});
		System.out.println(result);
		return result;
	}

	@Override
	public String addItemToCart(CartItemDto item) {
		CartItem newitem = mapper.map(item, CartItem.class);
		
		newitem.setRemoved(false);
		cartdao.save(newitem);
		
		return "Item added to cart";
	}

	@Override
	public String updateItemInCart(CartItemDto item) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String deleteItemfromCart(Long id) {
		Optional<CartItem> cartOpt = cartdao.findById(id);
		if(cartOpt.isPresent())
		{
			CartItem cartItem = cartOpt.get();
			cartItem.setRemoved(true);
			
			System.out.println(cartdao.save(cartItem));
			return "Item deleted";
		}
		return "Item NOT FOUND";
	}

}
