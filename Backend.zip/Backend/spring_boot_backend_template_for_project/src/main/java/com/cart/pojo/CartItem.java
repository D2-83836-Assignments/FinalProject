package com.cart.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "cart")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(callSuper = true)
public class CartItem extends BaseEntity{	
	@Column(length = 50)
	private String title;
	
	@Column(length = 100)
	private String description;
	
	@Column(length = 100)
	private String imgpath;
	
	@Column
	private double price;
	
	@Column
	private double discount;
	
	@Column
	private int quantity;
	
	@Column(name = "net_price")
	private double netprice;
	
	@Column(name = "is_removed", nullable = false, columnDefinition = "TINYINT(1)")
	private boolean isRemoved = false;
}
