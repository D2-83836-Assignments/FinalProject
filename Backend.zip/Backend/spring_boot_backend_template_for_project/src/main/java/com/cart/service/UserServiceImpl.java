package com.cart.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cart.dao.UserDao;
import com.cart.dto.UserDto;
import com.cart.pojo.User;

@Service
@Transactional
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userdao;
	
	@Autowired
	private ModelMapper mapper;

	@Override
	public UserDto getUserById(Long id) {
		Optional<User>userOpt = userdao.findById(id);
		
		if(userOpt.isPresent())
		{
			User user = userOpt.get();
			UserDto userdto = mapper.map(user, UserDto.class);
			return userdto;
		}
		return null;
	}

	@Override
	public List<UserDto> getAllUsers() {
		List<User> userList = userdao.findAll();
		List<UserDto> result = new ArrayList<UserDto>();
		
		userList.forEach((user)->{
			result.add(mapper.map(user, UserDto.class));
		});
		System.out.println(result);
		return result;
	}

	@Override
	public String addUser(UserDto userDto) {
		User newUser = mapper.map(userDto, User.class);
		
		userdao.save(newUser);
		
		return "User added";
	}

	@Override
	public String updateUserDetails(UserDto userDto) {
		
//		System.out.println("User exists");
		Optional<User> userOpt = userdao.findById(userDto.getId());
		if(userOpt.isPresent())
		{
			User existing = userOpt.get();
//			System.out.println("User found: "+existing);
			User updateUser = mapper.map(userDto, User.class);
			updateUser.setItems(existing.getItems());
			
			System.out.println(userdao.save(updateUser));
			return "User updated";
		}
		return "User NOT FOUND";
	}

	@Override
	public String deleteUserDetails(Long id) {
		Optional<User> userOpt = userdao.findById(id);
		if(userOpt.isPresent())
		{
			userdao.deleteById(id);
			return "User deleted";
		}
		return "User NOT FOUND";
	}

}
